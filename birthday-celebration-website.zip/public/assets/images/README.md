# Image Files

This directory should contain image files for the birthday celebration website.

For a real implementation, you would need to add:
- birthday-hero.jpg - A hero image for the homepage
- cake.png - A birthday cake image
- balloon.png - A balloon image
- favicon.ico - Website favicon
