# Audio Files

This directory should contain audio files for the birthday celebration website.

For a real implementation, you would need to add:
- happy-birthday.mp3 - A happy birthday song
- celebration.mp3 - A celebration sound effect
